﻿using Nba.Domain.Concrete;
using Nba.Persistence;
using System;
using System.Linq;

namespace Nba.App
{
    class Program
    {
        static void Main(string[] args)
        {
            //InsertGame();
            //InsertLarryBird();
            //UpdateLarryBird();
            //UpdateLarryBirdsTeam();
            //InsertScottiePippen();
        }

        private static void InsertScottiePippen()
        {
            var db = new NbaDbContext();

            var scottiePippen = new Player
            {
                FirstName = "Scottie",
                LastName = "Pippen",
                JerseyNo = "33",
                BirthDate = new DateTime(1965, 9, 25),
                DraftYear = 1987,
                Height = 6.8
            };

            db.Players.Add(scottiePippen);
            db.SaveChanges();
        }

        private static void UpdateLarryBirdsTeam()
        {
            var db = new NbaDbContext();

            var bostonId = db.Teams.FirstOrDefault(x => x.Name.Contains("boston"))?.Id;

            if (bostonId == null)
            {
                Console.WriteLine("No such team");
                return;
            }

            var larryBird = db.Players.FirstOrDefault(x => x.FirstName == "Larry" && x.LastName == "Bird");

            if (larryBird == null)
            {
                Console.WriteLine("No such player");
                return;
            }

            //If we got this far, everything is OK
            larryBird.TeamId = bostonId;
            db.SaveChanges();
        }

        private static void UpdateLarryBird()
        {
            //1. check if such player exists with given first name and last name
            var db = new NbaDbContext();

            try
            {
                var larryBird = db.Players.SingleOrDefault(x => x.FirstName == "Larry" && x.LastName == "Bird");

                if (larryBird != null)
                { // expected behaviour
                    larryBird.JerseyNo = "33";
                    db.SaveChanges(); 
                }
                else
                    Console.WriteLine("There is no player satisfies the condition");
            }
            catch (InvalidOperationException ioe)
            {
                Console.WriteLine("There are more than one player satisfies the condition");
            }
        }

        private static void InsertLarryBird()
        {
            var db = new NbaDbContext();

            var larryBird = new Player
            {
                FirstName = "Larry",
                LastName = "Bird",
                JerseyNo = "23", // should be 33, but we inserted it on purpose
                BirthDate = new DateTime(1956, 12, 7),
                DraftYear = 1978,
                Height = 6.9
            };

            db.Players.Add(larryBird);
            db.SaveChanges();
        }

        private static void InsertGame()
        {
            var db = new NbaDbContext();

            var bostonId = db.Teams.FirstOrDefault(x => x.Name.Contains("boston"))?.Id;
            var sixersId = db.Teams.FirstOrDefault(x => x.Name.Contains("philedelphia"))?.Id;

            if (bostonId != null || sixersId != null)
            {
                var game = new Game
                {
                    GameDate = new DateTime(2020, 1, 10),
                    GuestTeamId = bostonId.Value,
                    HomeTeamId = sixersId.Value,
                    GuestTeamScore = 98,
                    HomeTeamScore = 101
                };

                db.Games.Add(game);
                db.SaveChanges();
            }
            else
                Console.WriteLine("At least one of the teams are absent");
        }
    }
}


