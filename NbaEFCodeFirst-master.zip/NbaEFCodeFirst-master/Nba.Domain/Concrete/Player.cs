﻿using Nba.Domain.Abstractions;

namespace Nba.Domain.Concrete
{
    public class Player : Person
    {
        public string JerseyNo { get; set; }
        /// <summary>
        /// Height of the player in ft
        /// </summary>
        public double Height { get; set; }
        public int? DraftYear { get; set; }

        public int? TeamId { get; set; }

        //[ForeignKey(nameof(TeamId))]
        public Team Team { get; set; }
        //Navigation Property: gezinti özellikleri
    }
}
