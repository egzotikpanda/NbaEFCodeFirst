﻿using Nba.Domain.Abstractions;

namespace Nba.Domain.Concrete
{
    public class Team: BaseEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public int ConferenceId { get; set; }
        public Conference Conference { get; set; }

        public Coach Coach { get; set; }
        public int? CoachId { get; set; }
        //Principal
    }
}
