﻿using Nba.Domain.Abstractions;
using System.Collections.Generic;

namespace Nba.Domain.Concrete
{
    public class Conference: BaseEntity
    {
        public Conference()
        {
            Teams = new HashSet<Team>();
        }

        public int Id { get; set; }
        public string Name { get; set; }

        public ICollection<Team> Teams { get; set; }
    }
}
