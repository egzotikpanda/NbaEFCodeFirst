﻿using Nba.Domain.Abstractions;

namespace Nba.Domain.Concrete
{
    public class Coach : Person
    {
        public int? TeamId { get; set; }
        public Team Team { get; set; }
        public double Salary { get; set; }
    }
}
