﻿using System;

namespace Nba.Domain.Abstractions
{
    /// <summary>
    /// Base class for any person implementation wihtin the application
    /// </summary>
    public abstract class Person: BaseEntity
    {
        //Convention over configuration
        public int Id { get; set; }
        //[Required]
        public string FirstName { get; set; }
        //[Required]
        public string LastName { get; set; }
        public DateTime? BirthDate { get; set; }

        //OC principle
        //Software entities should be open for extension, close for modification

        // NOT NULL
        // String reference type olduğu için, yani null olabildiği için,
        //Default olarak nullable

        //package olarak indirildiği için ve nuget aracılığıyla indirildiği için
        //dünyanın hemen hemen tüm dll'leri aynı ortamda
        //versiyonlarla ilgili update olduğunda size haber ediyor ve hızlı update imkanı
        //pre-release (dev)
        //bazen bir package içinde n tane dll olabilir
        //ilgili package ismiyle bu dll'lerin hepsini tek bir harekette indiriytorsunuz

    }
}
