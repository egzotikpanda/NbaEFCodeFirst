﻿namespace Nba.Persistence.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedCoachesTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Coaches",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        TeamId = c.Int(),
                        Salary = c.Double(nullable: false),
                        FirstName = c.String(),
                        LastName = c.String(),
                        BirthDate = c.DateTime(),
                        Team_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Teams", t => t.Team_Id)
                .Index(t => t.Team_Id);
            
            AddColumn("dbo.Teams", "CoachId", c => c.Int());
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Coaches", "Team_Id", "dbo.Teams");
            DropIndex("dbo.Coaches", new[] { "Team_Id" });
            DropColumn("dbo.Teams", "CoachId");
            DropTable("dbo.Coaches");
        }
    }
}
