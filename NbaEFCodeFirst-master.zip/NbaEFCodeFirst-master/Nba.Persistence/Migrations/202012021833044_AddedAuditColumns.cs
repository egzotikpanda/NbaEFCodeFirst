﻿namespace Nba.Persistence.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedAuditColumns : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Coaches", "CreatedOn", c => c.DateTime());
            AddColumn("dbo.Coaches", "CreatedBy", c => c.String());
            AddColumn("dbo.Coaches", "LastModifiedOn", c => c.DateTime());
            AddColumn("dbo.Coaches", "LastModifiedBy", c => c.String());
            AddColumn("dbo.Teams", "CreatedOn", c => c.DateTime());
            AddColumn("dbo.Teams", "CreatedBy", c => c.String());
            AddColumn("dbo.Teams", "LastModifiedOn", c => c.DateTime());
            AddColumn("dbo.Teams", "LastModifiedBy", c => c.String());
            AddColumn("dbo.Conferences", "CreatedOn", c => c.DateTime());
            AddColumn("dbo.Conferences", "CreatedBy", c => c.String());
            AddColumn("dbo.Conferences", "LastModifiedOn", c => c.DateTime());
            AddColumn("dbo.Conferences", "LastModifiedBy", c => c.String());
            AddColumn("dbo.Players", "CreatedOn", c => c.DateTime());
            AddColumn("dbo.Players", "CreatedBy", c => c.String());
            AddColumn("dbo.Players", "LastModifiedOn", c => c.DateTime());
            AddColumn("dbo.Players", "LastModifiedBy", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Players", "LastModifiedBy");
            DropColumn("dbo.Players", "LastModifiedOn");
            DropColumn("dbo.Players", "CreatedBy");
            DropColumn("dbo.Players", "CreatedOn");
            DropColumn("dbo.Conferences", "LastModifiedBy");
            DropColumn("dbo.Conferences", "LastModifiedOn");
            DropColumn("dbo.Conferences", "CreatedBy");
            DropColumn("dbo.Conferences", "CreatedOn");
            DropColumn("dbo.Teams", "LastModifiedBy");
            DropColumn("dbo.Teams", "LastModifiedOn");
            DropColumn("dbo.Teams", "CreatedBy");
            DropColumn("dbo.Teams", "CreatedOn");
            DropColumn("dbo.Coaches", "LastModifiedBy");
            DropColumn("dbo.Coaches", "LastModifiedOn");
            DropColumn("dbo.Coaches", "CreatedBy");
            DropColumn("dbo.Coaches", "CreatedOn");
        }
    }
}
