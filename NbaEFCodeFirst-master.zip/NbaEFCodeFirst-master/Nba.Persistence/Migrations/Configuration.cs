﻿namespace Nba.Persistence.Migrations
{
    using Nba.Domain.Concrete;
    using System;
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<NbaDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            ContextKey = "Nba.Persistence.NbaDbContext";
        }

        protected override void Seed(NbaDbContext context)
        {
            var allenIverson = new Player
            {
                FirstName = "Allen",
                LastName = "Iverson",
                BirthDate = new DateTime(1975, 6, 7),
                DraftYear = 1996,
                Height = 6,
                JerseyNo = "00"
            };

            var rayAllen = new Player
            {
                FirstName = "Ray",
                LastName = "Allen",
                BirthDate = new DateTime(1975, 7, 20),
                DraftYear = 1996,
                Height = 6.5,
                JerseyNo = "20"
            };

            var easternConference = new Conference { Name = "Eastern" };
            var westernConference = new Conference { Name = "Western" };
            context.Conferences.AddOrUpdate(x => x.Name, easternConference, westernConference);
            context.SaveChanges();

            var bostonCeltics = new Team { Name = "Boston Celtics", ConferenceId = easternConference.Id };
            var philedelphia76ers = new Team { Name = "Philedelphia 76ers", ConferenceId = easternConference.Id };
            context.Teams.AddOrUpdate(x => x.Name, bostonCeltics, philedelphia76ers);
            context.SaveChanges();

            rayAllen.TeamId = 2;
            allenIverson.TeamId = 1;
            context.Players.AddOrUpdate(x => new { x.FirstName, x.LastName }, allenIverson, rayAllen);
            context.SaveChanges();

            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method
            //  to avoid creating duplicate seed data.

            //enable-migrations
            //add-migration MigrationName
            //update-database
        }
    }
}
