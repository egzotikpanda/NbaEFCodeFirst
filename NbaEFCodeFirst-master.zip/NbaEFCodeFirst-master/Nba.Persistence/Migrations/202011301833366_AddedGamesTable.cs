﻿namespace Nba.Persistence.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedGamesTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Games",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        GameDate = c.DateTime(nullable: false),
                        HomeTeamId = c.Int(nullable: false),
                        HomeTeamScore = c.Int(nullable: false),
                        GuestTeamId = c.Int(nullable: false),
                        GuestTeamScore = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Teams", t => t.GuestTeamId, cascadeDelete: false)
                .ForeignKey("dbo.Teams", t => t.HomeTeamId, cascadeDelete: false)
                .Index(t => t.HomeTeamId)
                .Index(t => t.GuestTeamId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Games", "HomeTeamId", "dbo.Teams");
            DropForeignKey("dbo.Games", "GuestTeamId", "dbo.Teams");
            DropIndex("dbo.Games", new[] { "GuestTeamId" });
            DropIndex("dbo.Games", new[] { "HomeTeamId" });
            DropTable("dbo.Games");
        }
    }
}
