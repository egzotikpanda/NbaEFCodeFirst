﻿using Nba.Domain.Concrete;
using System.Data.Entity.ModelConfiguration;

namespace Nba.Persistence.Configurations
{
    class TeamConfiguration:EntityTypeConfiguration<Team>
    {
        public TeamConfiguration()
        {
            Property(x => x.Name).IsRequired().HasMaxLength(100).HasColumnType("varchar");

            HasOptional(s => s.Coach)
                .WithOptionalPrincipal(ad => ad.Team);
        }
    }
}
