﻿using Nba.Domain.Concrete;
using System.Data.Entity.ModelConfiguration;

namespace Nba.Persistence.Configurations
{
    class ConferenceConfiguration : EntityTypeConfiguration<Conference>
    {
        //https://www.entityframeworktutorial.net/code-first/move-configurations-to-seperate-class-in-code-first.aspx
        public ConferenceConfiguration()
        {
            Property(x => x.Name).IsRequired().HasMaxLength(10).HasColumnType("varchar");
            HasMany(x => x.Teams).WithRequired(x => x.Conference); //Optional

            ToTable("Conferences", "dbo"); //default behaviour anyway

            //Auditable entity 

            //CreatedOn, CreatedBy, LastModifiedOn, LastModifiedBy

            //ChangeTracker => context'teki değişiklikleri izleyen obje

            //Entry => State => Modified, Added, Deleted, Unchanged

            //db.Employees.Add(sssss);

            //db.SaveChanges();

        }
    }
}
