﻿using Nba.Domain.Abstractions;
using Nba.Domain.Concrete;
using Nba.Persistence.Configurations;
using System;
using System.Data.Entity;
using System.Reflection;

namespace Nba.Persistence
{
    public class NbaDbContext : DbContext
    {
        public NbaDbContext() : base("name=NbaDbContext") //optional if it has the same name
        {
            Database.SetInitializer(new DropCreateDatabaseIfModelChanges<NbaDbContext>());
            //Eğer Model Değiştiyse Veritabanını Önce Uçur Sonra Oluştur
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //modelBuilder.Configurations.Add(new PlayerConfiguration());
            //modelBuilder.Configurations.Add(new TeamConfiguration());
            //modelBuilder.Configurations.Add(new ConferenceConfiguration());

            modelBuilder.Configurations.AddFromAssembly(Assembly.Load("Nba.Persistence"));

            //Fluent API
            //Api: Application Programming Interface
        }

        public override int SaveChanges()
        {
            foreach (var entry in ChangeTracker.Entries())
            {
                if (entry.Entity is BaseEntity)
                {
                    if (entry.State ==EntityState.Added)
                    {
                        var entity = (BaseEntity)entry.Entity;
                        entity.CreatedOn = DateTime.Now;
                        entity.CreatedBy = "svahabi@iakademi.com";
                    }
                    else if (entry.State == EntityState.Modified)
                    {
                        var entity = (BaseEntity)entry.Entity;
                        entity.LastModifiedOn = DateTime.Now;
                        entity.LastModifiedBy = "svahabi@iakademi.com";
                    }
                }
            }
            return base.SaveChanges();
        }

        public DbSet<Team> Teams { get; set; }
        public DbSet<Player> Players { get; set; }
        public DbSet<Conference> Conferences { get; set; }
        public DbSet<Game> Games { get; set; }
        public DbSet<Coach> Coaches { get; set; }
    }
}
